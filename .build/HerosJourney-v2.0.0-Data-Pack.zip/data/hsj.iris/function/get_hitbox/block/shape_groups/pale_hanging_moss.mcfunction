execute if block ~ ~ ~ minecraft:pale_hanging_moss[tip=true] run data modify storage hsj.iris:data Shape set value [{min: [0.0625, 0.125, 0.0625], max: [0.9375, 1.0, 0.9375]}]
execute if block ~ ~ ~ minecraft:pale_hanging_moss[tip=false] run data modify storage hsj.iris:data Shape set value [{min: [0.0625, 0.0, 0.0625], max: [0.9375, 1.0, 0.9375]}]
