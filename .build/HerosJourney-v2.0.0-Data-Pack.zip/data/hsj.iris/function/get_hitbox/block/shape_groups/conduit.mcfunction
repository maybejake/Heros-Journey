data modify storage hsj.iris:data Shape set value [{min: [0.3125, 0.3125, 0.3125], max: [0.6875, 0.6875, 0.6875]}]
