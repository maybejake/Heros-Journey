data modify storage hsj.iris:data Shape set value [{min: [0.1875, 0.0, 0.1875], max: [0.8125, 0.625, 0.8125]}]
