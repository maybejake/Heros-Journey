scoreboard players set $entity_width hsj.iris 1950000
scoreboard players set $entity_height hsj.iris 2200000
