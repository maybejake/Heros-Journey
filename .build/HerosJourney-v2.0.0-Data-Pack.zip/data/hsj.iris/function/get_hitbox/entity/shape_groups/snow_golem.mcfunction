scoreboard players set $entity_width hsj.iris 700000
scoreboard players set $entity_height hsj.iris 1900000
