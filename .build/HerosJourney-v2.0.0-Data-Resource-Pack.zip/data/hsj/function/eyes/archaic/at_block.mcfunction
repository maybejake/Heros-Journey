execute if data block ~ ~ ~ item run return fail

say replaced
data modify block ~ ~ ~ LootTable set value "hsj:archaic_eye"